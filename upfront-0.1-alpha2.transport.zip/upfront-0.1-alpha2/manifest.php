<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'aeeba5ad074ea44e15b1228623a112cf',
      'native_key' => 'upfront',
      'filename' => 'modNamespace/9219013adf95487a661326c6df4fec9b.vehicle',
      'namespace' => 'upfront',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'ea538bc3f0631180c9cb8ca0171c5cb7',
      'native_key' => 1,
      'filename' => 'modPlugin/3e17811e1de9c272ca85dd19b0c50e8b.vehicle',
      'namespace' => 'upfront',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1f9003abbb3266b0e9c155ad5f3c3927',
      'native_key' => 1,
      'filename' => 'modCategory/306cbbf92ff34f31d18ce72263a6c851.vehicle',
      'namespace' => 'upfront',
    ),
  ),
);