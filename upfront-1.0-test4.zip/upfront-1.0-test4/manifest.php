<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3337ff81fb1f397aef4aff9b59172b0a',
      'native_key' => 'upfront',
      'filename' => 'modNamespace/5f1f3b4d1c366dc1c5e4e3555c30fcdb.vehicle',
      'namespace' => 'upfront',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'dc3623f94183b5aec9933dd9d2cb2c00',
      'native_key' => 1,
      'filename' => 'modPlugin/c77203fd7beaf5b52f778d199668d65f.vehicle',
      'namespace' => 'upfront',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0e239b5b4c20868c9b9a0758fcdd8bcb',
      'native_key' => 1,
      'filename' => 'modCategory/d152982e721d44809e37885432dd3f14.vehicle',
      'namespace' => 'upfront',
    ),
  ),
);