<?php

$_lang['upfront_welcome-back'] = 'Welcome back [[+username]]';
$_lang['upfront_resource_saved'] = 'Saved';
$_lang['upfront_resource_saved_msg'] = 'This page has been saved. Would you like to reload the page now to see the result?';
$_lang['upfront_site_tree'] = 'Site Pages';
$_lang['upfront_collapse_editor'] = "Close Editor";
$_lang['upfront_open_editor'] = "Open Editor";